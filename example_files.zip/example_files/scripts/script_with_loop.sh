#!/bin/bash

# This script will loop over some values
# and echo each one in turn:

# The seq command prints a sequence of numbers
# The -w option sets each number to be the same
# width, i.e. '00' rather than '0':
for value in `seq -w 0 10`
do
  echo "my value is: ${value}"
done
