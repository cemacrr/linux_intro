#!/bin/bash

# This script will echo the date then sleep
# for two seconds, while the value of 'count'
# is less than 5:

count=0

while [ "${count}" -lt "5" ]
do
  echo "count: ${count}"
  date
  sleep 2
  count=$((${count}+1))
done
