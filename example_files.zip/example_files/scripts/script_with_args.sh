#!/bin/bash

# This script will echo the first argument
# if it is not empty, otherwise it will echo
# an error message.

first=${1}

if [ "${first}" != "" ] ; then
  echo "script called with argument: ${first}"
else
  echo "error: no argument supplied"
  exit
fi
